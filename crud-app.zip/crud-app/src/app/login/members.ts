export class Members {
  memberId: number;
  memberName: string;
}
