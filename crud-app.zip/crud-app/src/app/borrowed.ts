export class Borrowed {
  id: number;
  bookId: number;
  memberId: number;
  issueDate: Date;
  dueDate: Date;
}
