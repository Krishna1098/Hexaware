export class Books {
  bookId: number;
  title: string;
  genre: string;
  price: number;
  availability:boolean;
}
