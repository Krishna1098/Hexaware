import React,{Component} from 'react';


export class LoginM extends Component{
    render(){
        return(
            <div className="container">

                <header>
                <h3 className="d-flex justify-content-center header-1">Sign In</h3>
                </header>

    <div className="d-flex justify-content-center">
     
     <div className="p-3 w-30 bd-highlight">
    
        <div className="input-group mb-3">
            <span className="input-group-text">EmpId</span>
            <input type="text" className="form-control"
            value={"Amlan"}/>
            </div>
        <div className="input-group mb-3">
            <span className="input-group-text">Email</span>
            <input type="text" className="form-control"
            value={"********"}/>
        
    </div>

        <a class="btn btn-primary m-2 float" href="/#/manager" role="button">Login</a>
            

        </div>
        </div>
        </div>

        )
    }
}