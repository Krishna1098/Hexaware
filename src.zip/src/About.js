import React,{Component} from 'react';


export class About extends Component{
    render(){
        return(
            <div className="container">
                <div>
                <header>
                <h3 className="d-flex justify-content-center header-1">About Page</h3>
                </header>
                </div>


                <a class="btn btn-primary m-2 float-end" href="/#/View" role="button">Back to Home</a>
            </div>

        )
    }
}