export const variables={
    API_URL:'http://localhost:21586/api/'  
}