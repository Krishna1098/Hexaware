﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CMSone.Migrations
{
    public partial class fourtMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Favourited",
                table: "Contact");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Favourited",
                table: "Contact",
                nullable: false,
                defaultValue: false);
        }
    }
}
