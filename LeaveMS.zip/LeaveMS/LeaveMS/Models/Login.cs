﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LeaveMS.Models
{
    public partial class Login
    {
        public int LoginId { get; set; }
        public string Password { get; set; }
    }
}
