import Home from "./home";

const RouteConfig={
    routes:[
        {
            path:'/Home',
            component:Home
        },
    ]
}
export default RouteConfig;