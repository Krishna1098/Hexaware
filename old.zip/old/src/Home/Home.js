import React,{Component} from 'react';
import { Typography, Box } from '@mui/material';
import { NavLink } from 'react-router-dom';


export class Home extends Component{
    render(){
        return(
            <div className="App container">
            <header>
            <h3 className="d-flex justify-content-center header-1">
              Welcome to Leave Management System
            </h3>
            </header>
            
            <marquee>Hexaware Technologies pvt.ltd</marquee>

              
            <nav className="navbar navbar-expand-sm bg-light navbar-dark">
              <ul className="navbar-nav">
                <li className="nav-item- m-1">
                  <NavLink className="btn btn-light btn-outline-primary" to="/home">
                    Home
                  </NavLink>
                </li>

                <li className="nav-item- m-1">
                  <NavLink className="btn btn-light btn-outline-primary" to="/myLeaves">
                    Services
                  </NavLink>
                </li>
                <li className="nav-item- m-1">
                  <NavLink className="btn btn-light btn-outline-primary" to="/contact">
                    Contacts
                  </NavLink>
                </li>
                <li className="nav-item- m-1">
                  <NavLink className="btn btn-light btn-outline-primary" to="/about">
                    About
                  </NavLink>
                </li>
                <li className="nav-item- m-1">
                  <NavLink className="btn btn-light btn-outline-primary" to="/SignIn">
                    LogOut
                  </NavLink>
                </li>
              </ul>
            </nav>



{/*             
      <Routes>
        <Route exact path='/home' element={<Home/>}/>
        <Route exact path='/contact' element={<Contact/>}/>
        <Route exact path='/myLeaves' element={<Leave/>}/>
        
      </Routes> */}
    </div>
      
        )
    }
}