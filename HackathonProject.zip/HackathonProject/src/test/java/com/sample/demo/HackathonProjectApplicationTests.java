package com.sample.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackathonProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
